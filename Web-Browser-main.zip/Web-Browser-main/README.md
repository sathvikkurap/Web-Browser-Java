# Web-Browser This is a web browser in Java! Made by watching a tutorial. 

This offers the capability to load most images, and keeps a log of the sites you searched, in the searched.txt file. 

I am currently a 6th grader who loves to code (mainly in Java). 
# Setup and Instructions 

# Main method (also the easiest one but I am not sure whether it includes the short term memory log of what you have searched)

Download the "WebBrowser.jar" file and run it.
Although I'm not sure whether it will include the capability for a short-term memory of the sites that you have searched, you can still access all of the functions of it. 

# Other method (For people who want the "searched.txt" file) 

You will need a Java IDE (such as  Eclipse or NetBeans). To start change your default browser in your IDE to Chrome (or a different browser if you don't have that option, since usually those are better than the actual default IDE browser). Next, import all the files in the repository except the "WebBrowser.jar" file. Finally, run the program through "ReadFile.java". When you run the program, currently, you have to put a "http://" at the start of your search, and it should load! # After following one of these methods you should be good to go! Thanks for checking out my project, and it would be great if you could star this repository!
