module module1 {
requires java.desktop;
}